package com.company;

public class PacienteExcepcion extends Exception{


    public PacienteExcepcion(String message) {
        super(message);
    }
}
