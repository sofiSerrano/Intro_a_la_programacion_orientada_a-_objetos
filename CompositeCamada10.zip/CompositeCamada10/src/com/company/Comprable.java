package com.company;

public interface Comprable {
    public Double calcularPrecio();
}
