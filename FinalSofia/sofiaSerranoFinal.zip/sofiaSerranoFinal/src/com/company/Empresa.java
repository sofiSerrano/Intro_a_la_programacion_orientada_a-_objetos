package com.company;

import java.util.ArrayList;
import java.util.List;

public class Empresa{
    private List<Servicio> servicios;

    public Empresa(List<Servicio> servicios) {
        this.servicios = new ArrayList<>();
    }

    public Empresa() {

    }


    public void mostrarServicios(){
        for(Servicio servicio: servicios){
            System.out.println("Nombre: " + servicio.getNombre() +
                    ", tipo: " + servicio.getClass().getSimpleName() +
                    ", puntaje: " + servicio.calcularPrecio());
        }
    }
    public void agregarServicio(Servicio s){servicios.add(s);}
}
