package com.company;
import java.util.ArrayList;
import java.util.List;

public class Combo extends Servicio{
    private List<Servicio> servicios;

    public Combo(String nombre, String descripcion) {
        super(nombre,descripcion);
    }
    public Combo(String nombre, String descripcion, List<Servicio> servicios) {
        super(nombre,descripcion);
        this.servicios = new ArrayList<>();
    }



    public void combo(){
        this.servicios=new ArrayList<>();
    }
    public void agregarServicio(Servicio s){
        servicios.add(s);
    }

    @Override
    public double calcularPrecio() {
        double precioTotal =0;
        for(Servicio servicio : servicios){
            precioTotal+=servicio.calcularPrecio();
        }
        return precioTotal;
    }


}
