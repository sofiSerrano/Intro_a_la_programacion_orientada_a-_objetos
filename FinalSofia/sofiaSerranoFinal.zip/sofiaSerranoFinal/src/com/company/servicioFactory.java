package com.company;

public class servicioFactory {
    private static servicioFactory factory = null;
    public static final String SIMPLE = "Servio Simple";
    public static final String COMBO = "Servio combinado";

    private  servicioFactory(){}

    public static servicioFactory getInstance(){
        if(factory == null){
            factory = new servicioFactory();
        }
        return factory;
    }

    public Servicio cargarServicio(String tipoServicio){
        switch(tipoServicio) {
            case servicioFactory.SIMPLE:
                return new Simple();
            case servicioFactory.COMBO:
                return new Combo();
        }
        return null;
    }
}
