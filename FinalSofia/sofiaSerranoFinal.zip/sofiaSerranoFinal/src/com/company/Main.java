package com.company;

public class Main {

    public static void main(String[] args) {
        /*Servicio simple: “Venta de aire acondicionado” que tiene un precio de 65.000 pesos
        Servicio simple: “Colocación” que tiene un precio base de 10.000 pesos y final de
        11.000 por ser un servicio de “Colocación”.
        Combo de servicios: contiene los dos servicios simples anteriores, este combo tiene
        un descuento del 10%, es decir, un precio de 68.400 pesos.*/

       Empresa empresa = new Empresa();
       Simple nuevo = new Simple(65000,"Venta","Venta aire acondicionado");
       empresa.agregarServicio(nuevo);
       Simple nuevo2 = new Simple(10000.00,"Colocacion","Colocacion");
       empresa.mostrarServicios();
    }
}