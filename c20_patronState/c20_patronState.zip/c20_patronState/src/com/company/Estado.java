package com.company;

public interface Estado {
    void Volver();
    void Seguir();
    void Cancelar();
    void Agregar();
}
