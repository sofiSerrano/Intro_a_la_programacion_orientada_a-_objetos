package com.company;

public class Pagando implements Estado{
    private Carrito c;

    public Pagando(Carrito c) {
        this.c = c;
    }

    @Override
    public void Volver() {

    }

    @Override
    public void Seguir() {

    }

    @Override
    public void Cancelar() {

    }

    @Override
    public void Agregar() {

    }
}
