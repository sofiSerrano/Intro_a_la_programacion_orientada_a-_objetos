package com.company;

public class Cargando implements Estado{
    private Carrito c;

    public Cargando(Carrito c) {
        this.c = c;
    }

    @Override
    public void Volver() {

    }

    @Override
    public void Seguir() {

    }

    @Override
    public void Cancelar() {

    }

    @Override
    public void Agregar() {

    }
}
