package com.company;

public class Carrito {
    private Estado estado;
    private Producto producto;

    public void AgregarProducto(Producto producto){};
    public void CancelarCarrito(){};
    public void VolverEstadoAnterior(){};
    public void PasarSiguienteEstado() {};
}
