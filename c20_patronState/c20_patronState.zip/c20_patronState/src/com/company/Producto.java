package com.company;

public class Producto {
}
