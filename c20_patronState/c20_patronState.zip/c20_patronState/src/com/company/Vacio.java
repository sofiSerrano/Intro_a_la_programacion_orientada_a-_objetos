package com.company;

public class Vacio implements Estado{
    private Carrito c;

    public Vacio(Carrito c) {
        this.c = c;
    }

    @Override
    public void Volver() {

    }

    @Override
    public void Seguir() {

    }

    @Override
    public void Cancelar() {

    }

    @Override
    public void Agregar() {

    }
}
