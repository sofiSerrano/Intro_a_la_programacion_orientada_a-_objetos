package com.company;

public class Cerrado implements Estado{
    private Carrito c;

    public Cerrado(Carrito c) {
        this.c = c;
    }

    @Override
    public void Volver() {
        return System.out.println("No puede volver al estado de Pagar");
    };
    }

    @Override
    public void Seguir() {

    }

    @Override
    public void Cancelar() {

    }

    @Override
    public void Agregar() {

    }
}
